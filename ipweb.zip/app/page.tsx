"use client"

import { useState } from "react"
import { IPInfo } from "@/components/ip-info"
import { TaxLookup } from "@/components/tax-lookup"
import { PDFTools } from "@/components/pdf-tools"
import { Globe, Building2, FileText } from "lucide-react"

type Tab = "ip" | "tax" | "pdf"

export default function Home() {
  const [activeTab, setActiveTab] = useState<Tab>("ip")

  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        {/* SEO Header */}
        <section className="mb-8 text-center">
          <h1 className="text-3xl font-bold tracking-tight text-foreground">
            Check IP, tra cứu mã số thuế và công cụ PDF miễn phí
          </h1>

          <p className="mt-3 text-muted-foreground leading-relaxed">
            Kiểm tra địa chỉ IP, xem vị trí IP, tra cứu mã số thuế doanh nghiệp,
            chuyển PDF sang ảnh, trích xuất PDF sang DOC/CSV, nén PDF và ghép
            ảnh thành PDF ngay trên trình duyệt.
          </p>
        </section>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex rounded-lg border border-border p-1 bg-muted/50">
            <button
              onClick={() => setActiveTab("ip")}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === "ip"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Globe className="h-4 w-4" />
              Check IP
            </button>

            <button
              onClick={() => setActiveTab("tax")}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === "tax"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Building2 className="h-4 w-4" />
              Mã Số Thuế
            </button>

            <button
              onClick={() => setActiveTab("pdf")}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === "pdf"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <FileText className="h-4 w-4" />
              Công cụ PDF
            </button>
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === "ip" && <IPInfo />}
        {activeTab === "tax" && <TaxLookup />}
        {activeTab === "pdf" && <PDFTools />}

        {/* SEO Content */}
        <section className="mt-12 rounded-lg border border-border bg-muted/30 p-6 text-sm text-muted-foreground leading-relaxed">
          <h2 className="text-lg font-semibold text-foreground mb-3">
            Công cụ tra cứu và xử lý PDF online
          </h2>

          <p>
            IPWeb cung cấp các công cụ miễn phí giúp bạn kiểm tra thông tin IP,
            tra cứu mã số thuế doanh nghiệp và xử lý file PDF trực tuyến. Các
            công cụ PDF hỗ trợ chuyển PDF sang ảnh PNG, trích xuất nội dung PDF
            sang DOC hoặc CSV, nén PDF và ghép nhiều ảnh JPG/PNG thành một file
            PDF.
          </p>

          <p className="mt-3">
            Phần xử lý PDF được thực hiện ngay trên trình duyệt, giúp hạn chế
            việc gửi tài liệu lên máy chủ và tăng tính riêng tư khi sử dụng.
          </p>
        </section>

        {/* Footer */}
        <footer className="mt-12 pt-8 border-t border-border text-center text-sm text-muted-foreground">
          <p>Check IP | Tra cứu Mã Số Thuế | Công cụ PDF - Miễn phí</p>
        </footer>
      </div>
    </main>
  )
}